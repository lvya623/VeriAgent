# Working memory（当前任务中间结果）+ Episodic memory（历史任务摘要）。
from typing import Dict, List


class WorkingMemory:
    def __init__(self):
        self._d: Dict[str, object] = {}

    def set(self, k, v):
        self._d[k] = v

    def get(self, k, default=None):
        return self._d.get(k, default)

    def snapshot(self):
        return dict(self._d)


class EpisodicMemory:
    def __init__(self):
        self._items: List[dict] = []

    def add(self, task_id, question, conclusion, score):
        self._items.append({"task_id": task_id, "question": question,
                            "conclusion": conclusion, "score": score})

    def similar(self, question, k=2):
        q = set(question)
        ranked = sorted(self._items,
                        key=lambda x: -len(q & set(x["question"])))
        return ranked[:k]

    def __len__(self):
        return len(self._items)
