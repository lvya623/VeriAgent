# 全链路运行观测：每步 Plan / 工具调用 / 校验都留一条 span。
from dataclasses import dataclass, field, asdict
from typing import Dict, List
import time


@dataclass
class TraceEvent:
    task_id: str
    node_id: str
    kind: str
    payload: dict
    tokens: int = 0
    latency_ms: float = 0.0
    cost_usd: float = 0.0
    ts: float = field(default_factory=time.time)


class Tracer:
    def __init__(self):
        self._events: List[TraceEvent] = []

    def emit(self, task_id, node_id, kind, payload=None,
             tokens=0, latency_ms=0.0, cost_usd=0.0):
        ev = TraceEvent(task_id, node_id, kind, payload or {},
                        tokens, latency_ms, cost_usd)
        self._events.append(ev)
        return ev

    def events(self, task_id=None) -> List[TraceEvent]:
        if task_id is None:
            return list(self._events)
        return [e for e in self._events if e.task_id == task_id]

    def summary(self, task_id) -> dict:
        ev = self.events(task_id)
        steps = [e for e in ev if e.kind == "skill_call"]
        return {
            "events": len(ev),
            "skill_calls": len(steps),
            "tokens": sum(e.tokens for e in ev),
            "latency_ms": round(sum(e.latency_ms for e in ev), 2),
            "cost_usd": round(sum(e.cost_usd for e in ev), 6),
            "warnings": [e.payload for e in ev if e.kind in ("blocked", "retry")],
            "recoveries": sum(1 for e in ev if e.kind == "recover"),
        }

    def as_dicts(self, task_id=None):
        return [asdict(e) for e in self.events(task_id)]
