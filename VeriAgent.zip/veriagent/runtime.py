# Plan-Act-Observe 主循环：结构化计划、权限/确认闸门、Checkpoint 恢复、防死循环。
import time
import uuid
from dataclasses import dataclass, field
from typing import List, Optional
from .schemas import Plan, Report, Claim, Evidence, SchemaError
from .state import TaskState, StateStore, Checkpoint, StateError
from .trace import Tracer
from .skills import SkillRegistry
from .memory import WorkingMemory, EpisodicMemory
from .search import hybrid_search, agentic_search
from .mcp_client import MCPClient, MCPError


@dataclass
class RunResult:
    task_id: str
    state: str
    report: Optional[Report] = None
    evidences: List[Evidence] = field(default_factory=list)
    checkpoints: int = 0
    pending_action: Optional[dict] = None
    trace_summary: dict = field(default_factory=dict)
    search_log: list = field(default_factory=list)


DEFAULT_CONFIG = {"agentic": True, "checkpoint": True,
                  "verifier": True, "strict_write": True,
                  "max_steps": 12, "max_repeats": 2, "wall_clock_s": 60}


class AgentRuntime:
    def __init__(self, llm, registry: SkillRegistry, mcp: MCPClient, index,
                 store: Optional[StateStore] = None, tracer: Optional[Tracer] = None,
                 config: Optional[dict] = None, auto_approve: bool = False,
                 authorized_exec: bool = False):
        self.llm = llm
        self.registry = registry
        self.mcp = mcp
        self.index = index
        self.store = store or StateStore()
        self.tracer = tracer or Tracer()
        self.cfg = dict(DEFAULT_CONFIG)
        if config:
            self.cfg.update(config)
        self.auto_approve = auto_approve
        self.authorized_exec = authorized_exec
        self.working = WorkingMemory()
        self.episodic = EpisodicMemory()
        self._sessions = {}
        self._wire_skills()

    def _wire_skills(self):
        # 工具由 MCP tools/list 动态发现，再绑定到本地实现
        self.mcp.initialize()
        tools = self.mcp.list_tools()
        self.tool_names = [t["name"] for t in tools]

        def search_fn(args):
            q = args["query"]
            if self.cfg["agentic"]:
                evs, rounds, log = agentic_search(q, self.index, max_rounds=3,
                                                  tracer=self.tracer,
                                                  task_id=args.get("_task_id", ""), topk=8)
                self.working.set("_search_log", log)
                return evs
            return hybrid_search(q, self.index, topk=6)

        def extract_fn(args):
            evs = args.get("evidences") or self.working.get("evidences", [])
            facts = [{"key": e.key(), "text": e.text[:160], "doc": e.doc_id}
                     for e in evs[:6]]
            return facts

        def write_fn(args):
            evs = self.working.get("evidences", [])
            return self.llm.write(args["question"], evs,
                                  strict=self.cfg["strict_write"])

        def verify_fn(args):
            report = self.working.get("report")
            if report is None:
                raise SchemaError("verify requires a report in working memory")
            evs = self.working.get("evidences", [])
            valid = {e.key() for e in evs}
            if not self.cfg["verifier"]:
                return report
            kept = [c for c in report.claims
                    if c.evidence_ids and all(x in valid for x in c.evidence_ids)]
            report.claims = kept
            report.confidence = round(min(0.95, report.confidence + 0.08), 2)
            return report

        def calc_fn(args):
            return self.mcp.call_tool("calc.compare", {"a": args.get("a", 0),
                                                       "b": args.get("b", 0)})

        self.registry.register(self.registry.spec("search"), search_fn)
        self.registry.register(self.registry.spec("extract"), extract_fn)
        self.registry.register(self.registry.spec("write_report"), write_fn)
        self.registry.register(self.registry.spec("verify"), verify_fn)
        self.registry.register(self.registry.spec("run_calculation"), calc_fn)

    def _resolve(self, v, task_id):
        if isinstance(v, str) and v.startswith("@memory."):
            return self.working.get(v[len("@memory."):])
        return v

    def start(self, question, task_id=None) -> RunResult:
        task_id = task_id or uuid.uuid4().hex[:12]
        self.store.transition(task_id, TaskState.PLANNING)
        t0 = time.time()
        plan = self.llm.plan(question, self.tool_names)
        if not isinstance(plan, Plan):
            raise SchemaError("planner must return a validated Plan")
        self.tracer.emit(task_id, "plan", "plan", plan.to_dict(),
                         tokens=len(question) * 2, latency_ms=12.0, cost_usd=0.0002)
        self.store.transition(task_id, TaskState.RUNNING)
        self._sessions[task_id] = {"question": question, "plan": plan.to_dict(),
                                   "cursor": 0, "evidences": [], "report": None,
                                   "facts": [], "seen_actions": [], "t0": t0}
        return self._run(task_id)

    def _checkpoint(self, task_id, cursor, step, key):
        if not self.cfg["checkpoint"]:
            return
        self.store.save(Checkpoint(task_id, f"n{cursor}",
                                   self.store.state(task_id).value, cursor,
                                   dict(step.args), key))

    def _run(self, task_id) -> RunResult:
        s = self._sessions[task_id]
        plan = Plan.from_dict(s["plan"])
        steps = plan.steps
        while s["cursor"] < len(steps):
            if s["cursor"] > self.cfg["max_steps"] or \
               time.time() - s["t0"] > self.cfg["wall_clock_s"]:
                self.tracer.emit(task_id, f"n{s['cursor']}", "blocked",
                                 {"reason": "step/wall-clock budget exceeded"})
                self.store.transition(task_id, TaskState.FAILED)
                return self._result(task_id, TaskState.FAILED)
            step = steps[s["cursor"]]
            name, raw_args = step.skill, dict(step.args)
            args = {k: self._resolve(v, task_id) for k, v in raw_args.items()}
            args["_task_id"] = task_id
            self.registry.validate_args(name, args)
            spec = self.registry.spec(name)

            # 权限控制
            if spec.permission == "exec" and not self.authorized_exec:
                self.tracer.emit(task_id, f"n{s['cursor']}", "blocked",
                                 {"skill": name, "reason": "exec permission denied"})
                s["cursor"] += 1
                continue

            # 重复动作检测（防死循环）
            sig = (name, str(sorted((k, str(v)[:60]) for k, v in args.items()
                                    if k != "_task_id")))
            s["seen_actions"].append(sig)
            if s["seen_actions"].count(sig) > self.cfg["max_repeats"]:
                self.tracer.emit(task_id, f"n{s['cursor']}", "blocked",
                                 {"skill": name, "reason": "repeated action"})
                self.store.transition(task_id, TaskState.FAILED)
                return self._result(task_id, TaskState.FAILED)

            key = f"{task_id}:{s['cursor']}:{name}"
            self._checkpoint(task_id, s["cursor"], step, key)

            # 人工确认闸门
            if spec.needs_confirmation and not self.auto_approve:
                self.store.transition(task_id, TaskState.WAITING_HUMAN)
                action = {"node_id": f"n{s['cursor']}", "cursor": s["cursor"],
                          "skill": name, "args": {k: v for k, v in args.items()
                                                  if k != "_task_id"},
                          "idempotency_key": key}
                self.store.set_pending(task_id, action)
                self.tracer.emit(task_id, f"n{s['cursor']}", "await_human",
                                 {"skill": name, "permission": spec.permission})
                return self._result(task_id, TaskState.WAITING_HUMAN, action)

            self._execute(task_id, s, name, args, key)
        return self._finish(task_id)

    def _execute(self, task_id, s, name, args, key):
        if self.store.has_executed(key):
            self.tracer.emit(task_id, key, "idempotent_skip", {"skill": name})
            s["cursor"] += 1
            return
        t0 = time.time()
        try:
            out = self.registry.fn(name)(args)
            self.store.mark_executed(key)
        except Exception as e:
            self.store.transition(task_id, TaskState.RECOVERING)
            self.tracer.emit(task_id, key, "retry", {"skill": name, "error": str(e)})
            self.store.transition(task_id, TaskState.RUNNING)
            out = self.registry.fn(name)(args)
            self.store.mark_executed(key)
        self.tracer.emit(task_id, key, "skill_call",
                         {"skill": name, "permission": self.registry.spec(name).permission},
                         tokens=40, latency_ms=(time.time() - t0) * 1000,
                         cost_usd=0.0001)
        if name == "search":
            s["evidences"] = out
            self.working.set("evidences", out)
        elif name == "extract":
            s["facts"] = out
            self.working.set("facts", out)
        elif name == "write_report":
            s["report"] = out
            self.working.set("report", out)
            self.working.set("claims", out.claims)
        elif name == "verify":
            s["report"] = out
            self.working.set("report", out)
        s["cursor"] += 1

    def approve(self, task_id) -> RunResult:
        # 人工确认后从最近 Checkpoint 恢复，靠幂等键避免「确认一次、执行两次」
        cp = self.store.latest(task_id)
        action = self.store.pending(task_id)
        if not action:
            raise StateError("no pending action for task " + task_id)
        if cp is None:
            raise StateError("no checkpoint to resume from")
        self.store.clear_pending(task_id)
        self.store.transition(task_id, TaskState.RUNNING)
        self.tracer.emit(task_id, cp.node_id, "recover",
                         {"from": cp.state, "cursor": cp.cursor_idx,
                          "idempotency_key": cp.idempotency_key})
        s = self._sessions[task_id]
        s["cursor"] = cp.cursor_idx       # 从 checkpoint 恢复，而不是凭内存状态
        args = dict(action["args"])
        args["_task_id"] = task_id
        self._execute(task_id, s, action["skill"], args, cp.idempotency_key)
        return self._run(task_id)

    def _finish(self, task_id):
        s = self._sessions[task_id]
        self.store.transition(task_id, TaskState.DONE)
        rep = s["report"]
        self.episodic.add(task_id, s["question"],
                          rep.conclusion if rep else "", len(s["evidences"]))
        self.tracer.emit(task_id, "done", "done",
                         {"evidences": len(s["evidences"]),
                          "claims": len(rep.claims) if rep else 0})
        return self._result(task_id, TaskState.DONE)

    def _result(self, task_id, state, pending=None) -> RunResult:
        s = self._sessions[task_id]
        return RunResult(
            task_id=task_id, state=state.value, report=s.get("report"),
            evidences=s.get("evidences", []),
            checkpoints=len(self.store.checkpoints(task_id)),
            pending_action=pending,
            trace_summary=self.tracer.summary(task_id),
            search_log=self.working.get("_search_log", []),
        )
