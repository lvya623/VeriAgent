# VeriAgent: minimal Agent Runtime + Agentic Search reference implementation
__version__ = "0.1.0"
