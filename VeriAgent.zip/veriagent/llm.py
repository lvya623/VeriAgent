# 可插拔 LLM adapter。默认 MockLLM 保证 demo 零依赖可复现。
import json
import os
import urllib.request
from typing import List
from .schemas import Plan, Report, Claim, Evidence


class LLMAdapter:
    def plan(self, question, tool_names) -> Plan:
        raise NotImplementedError

    def write(self, question, evidences: List[Evidence], strict=True) -> Report:
        raise NotImplementedError

    def judge(self, question, report, gold) -> dict:
        raise NotImplementedError


class MockLLM(LLMAdapter):
    def plan(self, question, tool_names) -> Plan:
        # 真实场景里这里是 response_format=json_object 的结构化输出
        raw = {
            "goal": "基于可核验证据生成带引用的结构化报告：" + question,
            "steps": [
                {"skill": "search", "args": {"query": question},
                 "reason": "先做混合检索，必要时由 Runtime 触发多轮 Agentic Search"},
                {"skill": "extract", "args": {"evidences": "@memory.evidences"},
                 "reason": "把证据块归一为可用于写作的事实条目"},
                {"skill": "write_report", "args": {"question": question,
                                                    "facts": "@memory.facts"},
                 "reason": "生成报告；该 Skill 为 write 权限，需人工确认"},
                {"skill": "verify", "args": {"claims": "@memory.claims",
                                             "evidences": "@memory.evidences"},
                 "reason": "逐条校验结论是否被所引证据支持"},
            ],
            "stop_condition": "证据充分且所有结论均有有效引用，或达到步数预算",
        }
        return Plan.from_dict(raw)   # 过 schema 校验，非法计划直接抛错

    def write(self, question, evidences, strict=True) -> Report:
        claims = []
        for e in evidences[:4]:
            snippet = e.text.replace("\n", " ")[:52]
            claims.append(Claim(f"据 {e.doc_id} 记载：{snippet}",
                                [e.key()], 0.82))
        if not strict:
            # baseline 配置：故意加入无引用陈述，用来真实演示幻觉率如何被算出来
            claims.append(Claim("通常来说该方案在所有场景下都优于其他方案。", [], 0.55))
            claims.append(Claim("相关指标大约提升了三成左右。", [], 0.5))
        conclusion = "综合上述证据，" + question[:24] + " 的结论需按证据范围限定。"
        raw = {"question": question, "conclusion": conclusion,
               "claims": [{"text": c.text, "evidence_ids": c.evidence_ids,
                           "confidence": c.confidence} for c in claims],
               "open_issues": ["示例语料规模有限，结论不外推"],
               "confidence": 0.78 if strict else 0.62}
        return Report.from_dict(raw)

    def judge(self, question, report, gold) -> dict:
        gold_keys = {"::".join(g) for g in gold.get("gold_evidence", [])}
        valid_keys = set(gold.get("valid_evidence_keys", [])) | gold_keys
        cited = [eid for c in report.claims for eid in c.evidence_ids]
        correct = sum(1 for e in cited if e in valid_keys)
        unsupported = sum(1 for c in report.claims if not c.evidence_ids)
        return {
            "citation_precision": correct / len(cited) if cited else 0.0,
            "hallucination_rate": unsupported / len(report.claims) if report.claims else 0.0,
            "claim_count": len(report.claims),
        }


class OpenAICompatibleLLM(LLMAdapter):
    # 生产替换点：填环境变量后即可把 MockLLM 换成真实模型
    def __init__(self, base=None, key=None, model=None):
        self.base = base or os.getenv("VERIAGENT_API_BASE", "https://api.openai.com/v1")
        self.key = key or os.getenv("VERIAGENT_API_KEY", "")
        self.model = model or os.getenv("VERIAGENT_MODEL", "gpt-4o-mini")

    def _chat(self, system, user):
        body = json.dumps({
            "model": self.model,
            "response_format": {"type": "json_object"},
            "messages": [{"role": "system", "content": system},
                         {"role": "user", "content": user}],
        }).encode("utf-8")
        req = urllib.request.Request(self.base + "/chat/completions", data=body,
                                     headers={"Content-Type": "application/json",
                                              "Authorization": "Bearer " + self.key})
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read())["choices"][0]["message"]["content"]

    def plan(self, question, tool_names) -> Plan:
        raw = self._chat("输出严格 JSON：{goal, steps:[{skill,args,reason}], stop_condition}。"
                         "可用 skill：" + ", ".join(tool_names),
                         "请为以下问题制定结构化计划：" + question)
        return Plan.from_dict(json.loads(raw))

    def write(self, question, evidences, strict=True) -> Report:
        ctx = "\n".join(f"[{e.key()}] {e.text[:200]}" for e in evidences)
        raw = self._chat("输出严格 JSON 报告，每个结论必须带 evidence_ids 引用。",
                         f"问题：{question}\n证据：\n{ctx}")
        return Report.from_dict(json.loads(raw))

    def judge(self, question, report, gold) -> dict:
        return MockLLM().judge(question, report, gold)
