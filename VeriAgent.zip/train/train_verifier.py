# PyTorch Verifier：判断「结论是否被所引证据支持」。torch 缺失时给出清晰提示。
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def features(claim, evidences):
    ids = set(claim.get("evidence_ids", []))
    cited = [e for e in evidences if e in ids]
    q = set(claim.get("text", ""))
    overlap = 0.0
    for e in cited:
        overlap = max(overlap, len(q & set(e)) / max(1, len(q)))
    return [len(ids), len(cited), overlap, min(1.0, len(claim.get("text", "")) / 80)]


def main():
    try:
        import torch
        from torch import nn
    except ImportError:
        print("torch 未安装：跳过训练。安装 torch 后重跑本脚本即可，")
        print("数据构造逻辑见 train/build_sft.py，指标口径见 eval/benchmark.py。")
        return
    torch.manual_seed(42)
    samples = []
    ds = (ROOT / "eval" / "dataset.jsonl").read_text(encoding="utf-8").splitlines()
    # 用评测集标注构造玩具样本：有 gold_evidence 的引用为正例，空引用为负例
    for line in ds:
        if not line.strip():
            continue
        row = json.loads(line)
        gold = ["::".join(g) for g in row.get("gold_evidence", [])]
        samples.append((features({"text": row["question"], "evidence_ids": gold[:2]}, gold), 1.0))
        samples.append((features({"text": "无来源的泛化断言", "evidence_ids": []}, gold), 0.0))
    X = torch.tensor([s[0] for s in samples], dtype=torch.float32)
    y = torch.tensor([s[1] for s in samples], dtype=torch.float32).view(-1, 1)
    model = nn.Sequential(nn.Linear(4, 8), nn.ReLU(), nn.Linear(8, 1), nn.Sigmoid())
    opt = torch.optim.Adam(model.parameters(), lr=0.05)
    lossf = nn.BCELoss()
    for _ in range(200):
        opt.zero_grad()
        loss = lossf(model(X), y)
        loss.backward()
        opt.step()
    with torch.no_grad():
        pred = model(X).view(-1).tolist()
    pos = [p for p, s in zip(pred, samples) if s[1] == 1.0]
    neg = [p for p, s in zip(pred, samples) if s[1] == 0.0]
    auc = sum(1 for a in pos for b in neg if a > b) / max(1, len(pos) * len(neg))
    print(f"toy Verifier  AUC={auc:.3f}  final_loss={loss.item():.4f}  n={len(samples)}")
    print("注意：这是玩具样本，只演示训练管线；真实 AUC 需在真实轨迹上报告。")


if __name__ == "__main__":
    main()
