# 任务状态机 + Checkpoint + 幂等键。内存实现可一键换成 MySQL（见 schema.sql）。
from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, List, Optional
import time


class StateError(RuntimeError):
    pass


class TaskState(str, Enum):
    PENDING = "PENDING"
    PLANNING = "PLANNING"
    RUNNING = "RUNNING"
    WAITING_HUMAN = "WAITING_HUMAN"
    RECOVERING = "RECOVERING"
    DONE = "DONE"
    FAILED = "FAILED"


ALLOWED = {
    TaskState.PENDING: {TaskState.PLANNING, TaskState.FAILED},
    TaskState.PLANNING: {TaskState.RUNNING, TaskState.FAILED},
    TaskState.RUNNING: {TaskState.WAITING_HUMAN, TaskState.RECOVERING,
                        TaskState.DONE, TaskState.FAILED},
    TaskState.WAITING_HUMAN: {TaskState.RUNNING, TaskState.FAILED},
    TaskState.RECOVERING: {TaskState.RUNNING, TaskState.FAILED},
    TaskState.DONE: set(),
    TaskState.FAILED: set(),
}


@dataclass
class Checkpoint:
    task_id: str
    node_id: str
    state: str
    cursor_idx: int
    args: dict
    idempotency_key: str
    ts: float = field(default_factory=time.time)
    result_ref: str = ""


class StateStore:
    def __init__(self):
        self._state: Dict[str, TaskState] = {}
        self._cps: Dict[str, List[Checkpoint]] = {}
        self._executed: set = set()
        self._pending: Dict[str, dict] = {}

    def state(self, task_id):
        return self._state.get(task_id, TaskState.PENDING)

    def transition(self, task_id, new_state: TaskState):
        cur = self.state(task_id)
        if new_state not in ALLOWED.get(cur, set()):
            raise StateError(f"illegal transition {cur.value} -> {new_state.value}")
        self._state[task_id] = new_state
        return new_state

    def save(self, cp: Checkpoint):
        self._cps.setdefault(cp.task_id, []).append(cp)

    def latest(self, task_id) -> Optional[Checkpoint]:
        xs = self._cps.get(task_id, [])
        return xs[-1] if xs else None

    def checkpoints(self, task_id) -> List[Checkpoint]:
        return list(self._cps.get(task_id, []))

    def mark_executed(self, key):
        self._executed.add(key)

    def has_executed(self, key):
        return key in self._executed

    def set_pending(self, task_id, action: dict):
        self._pending[task_id] = action

    def pending(self, task_id) -> Optional[dict]:
        return self._pending.get(task_id)

    def clear_pending(self, task_id):
        self._pending.pop(task_id, None)
