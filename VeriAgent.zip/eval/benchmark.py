# 固定评测集上的消融 Benchmark。所有数字由本脚本真实计算。
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from veriagent.llm import MockLLM
from veriagent.skills import SkillRegistry
from veriagent.mcp_client import MCPClient, MCPServer, LocalTransport
from veriagent.search import load_corpus
from veriagent.runtime import AgentRuntime

ROOT = Path(__file__).resolve().parents[1]
CORPUS = ROOT / "data" / "corpus.jsonl"
DATASET = ROOT / "eval" / "dataset.jsonl"
RESULTS = ROOT / "eval" / "results.json"

CONFIGS = {
    "baseline": dict(agentic=False, checkpoint=False, verifier=False, strict_write=False),
    "+agentic_search": dict(agentic=True, checkpoint=False, verifier=False, strict_write=False),
    "+runtime_engineering": dict(agentic=True, checkpoint=True, verifier=False, strict_write=False),
    "+sft_dpo_verifier": dict(agentic=True, checkpoint=True, verifier=True, strict_write=True),
}


def build_runtime(index, config):
    reg = SkillRegistry()
    server = MCPServer(index)
    mcp = MCPClient(LocalTransport(server))
    return AgentRuntime(MockLLM(), reg, mcp, index,
                        config=config, auto_approve=True, authorized_exec=True)


def load_dataset():
    return [json.loads(l) for l in DATASET.read_text(encoding="utf-8").splitlines()
            if l.strip()]


def evaluate(index, rows, config, name):
    n = len(rows)
    recall_hits = cited = cited_ok = claims = unsupported = steps = 0
    completed = 0
    refused_when_unanswerable = 0
    for row in rows:
        rt = build_runtime(index, config)
        res = rt.start(row["question"])
        report = res.report
        gold = {"::".join(g) for g in row.get("gold_evidence", [])}
        got = {e.key() for e in res.evidences}
        recall_hits += len(gold & got) / max(1, len(gold))
        if report:
            for c in report.claims:
                claims += 1
                if not c.evidence_ids:
                    unsupported += 1
                for eid in c.evidence_ids:
                    cited += 1
                    if eid in gold:      # 引用必须落在标注证据内才算准确
                        cited_ok += 1
            strong = sum(1 for c in report.claims if c.evidence_ids)
            answerable = row.get("answerable", True)
            if answerable:
                if strong >= 2 and len(gold & got) >= 1 and report.confidence >= 0.6:
                    completed += 1
            else:
                if strong == 0:
                    completed += 1        # 正确拒答
                    refused_when_unanswerable += 1
        steps += res.trace_summary.get("skill_calls", 0)
    metrics = {
        "config": name,
        "n": n,
        "task_completion_rate": round(completed / n, 4),
        "evidence_recall_at5": round(recall_hits / n, 4),
        "citation_precision": round(cited_ok / max(1, cited), 4),
        "hallucination_rate": round(unsupported / max(1, claims), 4),
        "avg_skill_calls": round(steps / n, 2),
        "unanswerable_refusals": refused_when_unanswerable,
    }
    return metrics


def main():
    index = load_corpus(CORPUS)
    rows = load_dataset()
    out = []
    for name, cfg in CONFIGS.items():
        m = evaluate(index, rows, cfg, name)
        out.append(m)
        print(f"{name:24s} 完成率 {m['task_completion_rate']:.0%}  "
              f"证据召回 {m['evidence_recall_at5']:.0%}  "
              f"引用准确 {m['citation_precision']:.0%}  "
              f"幻觉率 {m['hallucination_rate']:.0%}  "
              f"平均步数 {m['avg_skill_calls']}")
    RESULTS.write_text(json.dumps({"seed": 42, "dataset": str(DATASET.name),
                                   "metrics": out}, ensure_ascii=False, indent=2),
                       encoding="utf-8")
    print("written:", RESULTS)
    print("说明：多轮检索扩大证据池后召回上升、引用精度可能下降；")
    print("      Verifier 的句子级对齐需单独优化，不要只看单一指标。")
    return out


if __name__ == "__main__":
    main()
