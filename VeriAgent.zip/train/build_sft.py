# 运行轨迹 -> SFT 数据（结构化 Plan + Tool 调用序列）与 DPO 偏好对。
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from veriagent.llm import MockLLM
from veriagent.skills import SkillRegistry
from veriagent.mcp_client import MCPClient, MCPServer, LocalTransport
from veriagent.search import load_corpus
from veriagent.runtime import AgentRuntime

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "train"


def build():
    index = load_corpus(ROOT / "data" / "corpus.jsonl")
    rows = [json.loads(l) for l in
            (ROOT / "eval" / "dataset.jsonl").read_text(encoding="utf-8").splitlines()
            if l.strip()]
    sft, dpo = [], []
    for row in rows:
        good = AgentRuntime(MockLLM(), SkillRegistry(),
                            MCPClient(LocalTransport(MCPServer(index))), index,
                            config=dict(agentic=True, checkpoint=True,
                                        verifier=True, strict_write=True),
                            auto_approve=True, authorized_exec=True)
        bad = AgentRuntime(MockLLM(), SkillRegistry(),
                           MCPClient(LocalTransport(MCPServer(index))), index,
                           config=dict(agentic=False, checkpoint=False,
                                       verifier=False, strict_write=False),
                           auto_approve=True, authorized_exec=True)
        rg, rb = good.start(row["question"]), bad.start(row["question"])
        plan = good.llm.plan(row["question"], good.tool_names)
        sft.append({"prompt": row["question"],
                    "completion": plan.to_dict(),
                    "tool_calls": [{"skill": "search", "evidence_keys":
                                    [e.key() for e in rg.evidences]}],
                    "quality": "chosen" if rg.report else "unknown"})
        if rg.report and rb.report:
            dpo.append({"prompt": row["question"],
                        "chosen": rg.report.to_dict(),
                        "rejected": rb.report.to_dict()})
    (OUT / "sft.jsonl").write_text(
        "\n".join(json.dumps(x, ensure_ascii=False) for x in sft) + "\n", encoding="utf-8")
    (OUT / "dpo.jsonl").write_text(
        "\n".join(json.dumps(x, ensure_ascii=False) for x in dpo) + "\n", encoding="utf-8")
    print(f"sft: {len(sft)} rows -> {OUT/'sft.jsonl'}")
    print(f"dpo: {len(dpo)} rows -> {OUT/'dpo.jsonl'}")
    print("说明：示例语料规模很小，仅用于演示数据管线；真实训练请接入真实轨迹。")


if __name__ == "__main__":
    build()
