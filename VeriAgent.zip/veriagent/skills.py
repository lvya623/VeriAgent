# Skill 注册表：声明式 schema + 权限 + 人工确认，Runtime 只负责编排。
from typing import Callable, Dict, List
from .schemas import SkillSpec, SchemaError


SKILL_SPECS = [
    SkillSpec("search", "read", False, 20, 2, ["query"], ["evidences"]),
    SkillSpec("extract", "read", False, 20, 2, ["evidences"], ["facts"]),
    SkillSpec("verify", "read", False, 20, 1, ["claims", "evidences"], ["claims"]),
    SkillSpec("write_report", "write", True, 30, 1,
              ["question", "facts"], ["report"]),
    SkillSpec("run_calculation", "exec", True, 15, 1,
              ["expression"], ["value"]),
]


class SkillRegistry:
    def __init__(self):
        self._specs: Dict[str, SkillSpec] = {}
        self._fns: Dict[str, Callable] = {}
        for s in SKILL_SPECS:
            self._specs[s.name] = s

    def register(self, spec: SkillSpec, fn: Callable):
        self._specs[spec.name] = spec
        self._fns[spec.name] = fn

    def spec(self, name: str) -> SkillSpec:
        if name not in self._specs:
            raise SchemaError(f"unknown skill: {name}")
        return self._specs[name]

    def fn(self, name: str) -> Callable:
        if name not in self._fns:
            raise SchemaError(f"skill not implemented: {name}")
        return self._fns[name]

    def validate_args(self, name: str, args: dict):
        spec = self.spec(name)
        missing = [k for k in spec.input_keys if k not in args]
        if missing:
            raise SchemaError(f"{name} missing args: {missing}")

    def describe(self) -> List[dict]:
        return [s.to_dict() for s in self._specs.values()]
