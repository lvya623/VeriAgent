# 结构化输出：所有跨模块数据都过 schema 校验，禁止自由文本计划。
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any
import json


class SchemaError(ValueError):
    pass


def _need(d: dict, keys, where):
    if not isinstance(d, dict):
        raise SchemaError(f"{where} must be an object")
    for k in keys:
        if k not in d:
            raise SchemaError(f"{where} missing field: {k}")


@dataclass
class PlanStep:
    skill: str
    args: Dict[str, Any]
    reason: str

    @classmethod
    def from_dict(cls, d):
        _need(d, ("skill", "args", "reason"), "PlanStep")
        if not isinstance(d["args"], dict):
            raise SchemaError("PlanStep.args must be an object")
        return cls(str(d["skill"]), dict(d["args"]), str(d["reason"]))


@dataclass
class Plan:
    goal: str
    steps: List[PlanStep]
    stop_condition: str

    @classmethod
    def from_dict(cls, d):
        _need(d, ("goal", "steps", "stop_condition"), "Plan")
        if not isinstance(d["steps"], list) or not d["steps"]:
            raise SchemaError("Plan.steps must be a non-empty list")
        steps = [PlanStep.from_dict(s) for s in d["steps"]]
        return cls(str(d["goal"]), steps, str(d["stop_condition"]))

    def to_dict(self):
        return {"goal": self.goal,
                "steps": [asdict(s) for s in self.steps],
                "stop_condition": self.stop_condition}


@dataclass
class Evidence:
    doc_id: str
    chunk_id: str
    text: str
    score: float

    def key(self):
        return f"{self.doc_id}::{self.chunk_id}"


@dataclass
class Claim:
    text: str
    evidence_ids: List[str] = field(default_factory=list)
    confidence: float = 0.5


@dataclass
class Report:
    question: str
    conclusion: str
    claims: List[Claim]
    open_issues: List[str] = field(default_factory=list)
    confidence: float = 0.5

    @classmethod
    def from_dict(cls, d):
        _need(d, ("question", "conclusion", "claims"), "Report")
        if not isinstance(d["claims"], list):
            raise SchemaError("Report.claims must be a list")
        claims = []
        for c in d["claims"]:
            _need(c, ("text", "evidence_ids"), "Claim")
            if not isinstance(c["evidence_ids"], list):
                raise SchemaError("Claim.evidence_ids must be a list")
            claims.append(Claim(str(c["text"]),
                                [str(x) for x in c["evidence_ids"]],
                                float(c.get("confidence", 0.5))))
        return cls(str(d["question"]), str(d["conclusion"]), claims,
                   [str(x) for x in d.get("open_issues", [])],
                   float(d.get("confidence", 0.5)))

    def to_dict(self):
        return {"question": self.question, "conclusion": self.conclusion,
                "claims": [asdict(c) for c in self.claims],
                "open_issues": self.open_issues, "confidence": self.confidence}


@dataclass
class SkillSpec:
    name: str
    permission: str                 # read | write | exec
    needs_confirmation: bool
    timeout_s: int
    max_retries: int
    input_keys: List[str]
    output_keys: List[str]

    def to_dict(self):
        return asdict(self)


def dumps(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=2)
