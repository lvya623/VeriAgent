# Agentic Search：结构感知分块、BM25+向量双索引、RRF 融合、证据充分性自反思。
import json
import math
import re
from collections import Counter
from pathlib import Path
from typing import Dict, List, Tuple
from .schemas import Evidence


def _tokens(s: str):
    s = s.lower()
    zh = re.findall(r"[\u4e00-\u9fff]{2,4}", s)
    en = re.findall(r"[a-z][a-z0-9_]{2,}", s)
    parts = []
    for w in zh:
        parts.extend([w, w[:2], w[1:3]])
    return parts + en + zh + en


def _vectorize(s: str):
    # 零依赖的 char 3-gram hashing 向量；生产环境替换为真实 embedding 即可。
    # 必须用 crc32 而非内置 hash()：后者受 PYTHONHASHSEED 随机化影响，
    # 会让同一份评测集在两次进程里检索结果漂移，破坏可复现性。
    import zlib
    v = Counter()
    for g in (s[i:i + 3] for i in range(max(0, len(s) - 2))):
        v[zlib.crc32(g.encode("utf-8")) % 512] += 1
    return v


def _cos(a, b):
    if not a or not b:
        return 0.0
    common = set(a) & set(b)
    dot = sum(a[k] * b[k] for k in common)
    na = math.sqrt(sum(x * x for x in a.values()))
    nb = math.sqrt(sum(x * x for x in b.values()))
    return dot / (na * nb) if na and nb else 0.0


def load_corpus(path) -> dict:
    chunks, docs = {}, []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        d = json.loads(line)
        docs.append(d)
        for sec in d["sections"]:
            key = f"{d['doc_id']}::{sec['chunk_id']}"
            chunks[key] = {"key": key, "doc_id": d["doc_id"],
                           "chunk_id": sec["chunk_id"],
                           "path": sec["path"], "text": sec["text"],
                           "title": d["title"]}
    inverted: Dict[str, Counter] = {}
    for key, c in chunks.items():
        tf = Counter(_tokens(c["text"] + " " + c["path"] + " " + c["title"]))
        for tok, n in tf.items():
            inverted.setdefault(tok, Counter())[key] += n
    N = max(1, len(chunks))
    idf = {tok: math.log(1 + N / (1 + len(post))) for tok, post in inverted.items()}
    vectors = {k: _vectorize(c["text"]) for k, c in chunks.items()}
    return {"chunks": chunks, "docs": docs, "inverted": inverted,
            "idf": idf, "vectors": vectors, "N": N}


def _bm25(query, index, topk):
    q = _tokens(query)
    scores: Counter = Counter()
    for tok in q:
        for key, tf in index["inverted"].get(tok, Counter()).items():
            scores[key] += index["idf"].get(tok, 0.0) * (1 + math.log(tf))
    return scores.most_common(topk * 3)


def hybrid_search(query, index, topk=5) -> List[Evidence]:
    bm = _bm25(query, index, topk)
    qv = _vectorize(query)
    vec_scores = [(k, _cos(qv, v)) for k, v in index["vectors"].items()]
    vec_scores.sort(key=lambda x: -x[1])
    # RRF 融合
    fused: Counter = Counter()
    for rank, (k, _) in enumerate(bm):
        fused[k] += 1.0 / (60 + rank + 1)
    for rank, (k, _) in enumerate(vec_scores[:topk * 3]):
        fused[k] += 1.0 / (60 + rank + 1)
    out = []
    for key, score in fused.most_common(topk):
        c = index["chunks"][key]
        out.append(Evidence(c["doc_id"], c["chunk_id"], c["text"], round(score, 6)))
    return out


def decompose(question):
    # 启发式 query 分解：对比类问题拆成「A + 主题」「B + 主题」「差异」
    parts = []
    m = re.search(r"(?:对比|比较)(.+?)与(.+?)(?:在|的|，|,|关于)(.+?)(?:上的|的)?(?:区别|差异|表现|适用)", question)
    if m:
        a, b, topic = m.group(1).strip(), m.group(2).strip(), m.group(3).strip()
        parts = [f"{a} {topic}", f"{b} {topic}", f"{a} {b} 差异 {topic}"]
    else:
        parts = [question]
        if "和" in question:
            parts += [s.strip() for s in question.split("和")[:2]]
    return [p for p in parts if p]


def sufficiency(question, evidences, min_docs=2, min_hits=3):
    qt = set(_tokens(question))
    hit = 0
    for e in evidences:
        if qt & set(_tokens(e.text)):
            hit += 1
    docs = len({e.doc_id for e in evidences})
    if docs < min_docs:
        return False, f"证据仅来自 {docs} 篇文档，需要跨文档关联"
    if hit < min_hits:
        return False, f"命中问题要点的证据块仅 {hit} 个"
    return True, f"覆盖 {docs} 篇文档、{hit} 个相关证据块"


def agentic_search(question, index, max_rounds=3, tracer=None, task_id="", topk=5):
    queries = decompose(question)
    seen, pool, log = set(), [], []
    rounds = 0
    for r in range(max_rounds):
        rounds += 1
        q = queries[min(r, len(queries) - 1)]
        got = hybrid_search(q, index, topk=topk)
        for e in got:
            if e.key() not in seen:
                seen.add(e.key())
                pool.append(e)
        ok, reason = sufficiency(question, pool)
        log.append({"round": r + 1, "query": q, "new": len(got), "pool": len(pool),
                    "sufficient": ok, "reason": reason})
        if tracer:
            tracer.emit(task_id, f"search.r{r + 1}", "search_round",
                        {"query": q, "sufficient": ok, "reason": reason},
                        tokens=len(q) * 2, latency_ms=8.0 + r * 2)
        if ok:
            break
        queries.append(q + " 适用条件 局限 对比")
    pool.sort(key=lambda e: -e.score)
    return pool[:topk * 2], rounds, log
