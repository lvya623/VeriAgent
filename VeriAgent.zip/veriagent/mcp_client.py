# 最小 MCP 风格 JSON-RPC client + 本地 server。
# initialize -> tools/list -> tools/call 三步不变；换 stdio/SSE 只需替换 transport。
import json
from typing import Dict, Any


class MCPError(RuntimeError):
    pass


TOOL_DESCRIPTORS = [
    {"name": "kb.search", "description": "混合检索知识库，返回带分数的证据块",
     "inputSchema": {"type": "object", "properties": {"query": {"type": "string"}},
                     "required": ["query"]}},
    {"name": "kb.get_chunk", "description": "按 doc_id/chunk_id 取回原文",
     "inputSchema": {"type": "object",
                     "properties": {"key": {"type": "string"}}, "required": ["key"]}},
    {"name": "calc.compare", "description": "对两组数值做差比较",
     "inputSchema": {"type": "object",
                     "properties": {"a": {"type": "number"}, "b": {"type": "number"}},
                     "required": ["a", "b"]}},
    {"name": "report.render", "description": "把结构化报告渲染成 Markdown",
     "inputSchema": {"type": "object",
                     "properties": {"report": {"type": "object"}},
                     "required": ["report"]}},
]


class MCPServer:
    def __init__(self, index):
        self.index = index
        self.calls = []

    def handle(self, req: dict) -> dict:
        method = req.get("method")
        rid = req.get("id")
        if method == "initialize":
            return {"jsonrpc": "2.0", "id": rid,
                    "result": {"protocolVersion": "2024-11-05",
                               "serverInfo": {"name": "veriagent-local", "version": "0.1"}}}
        if method == "tools/list":
            return {"jsonrpc": "2.0", "id": rid, "result": {"tools": TOOL_DESCRIPTORS}}
        if method == "tools/call":
            p = req.get("params", {})
            name, args = p.get("name"), p.get("arguments", {})
            self.calls.append({"tool": name, "args": args})
            try:
                result = self._invoke(name, args)
                return {"jsonrpc": "2.0", "id": rid, "result": {"content": result}}
            except Exception as e:
                return {"jsonrpc": "2.0", "id": rid, "error": {"message": str(e)}}
        return {"jsonrpc": "2.0", "id": rid, "error": {"message": "unknown method"}}

    def _invoke(self, name, args):
        if name == "kb.search":
            from .search import hybrid_search
            return [{"doc_id": e.doc_id, "chunk_id": e.chunk_id,
                     "text": e.text[:120], "score": round(e.score, 4)}
                    for e in hybrid_search(args["query"], self.index, topk=5)]
        if name == "kb.get_chunk":
            return {"key": args["key"], "text": self.index["chunks"].get(args["key"], "")}
        if name == "calc.compare":
            return {"a": args["a"], "b": args["b"], "diff": args["a"] - args["b"]}
        if name == "report.render":
            r = args["report"]
            lines = ["# " + r.get("question", "报告"), "", r.get("conclusion", "")]
            for c in r.get("claims", []):
                lines.append("- " + c.get("text", "") +
                             "  [" + ", ".join(c.get("evidence_ids", [])) + "]")
            return {"markdown": "\n".join(lines)}
        raise MCPError("unknown tool: " + str(name))


class LocalTransport:
    def __init__(self, server: MCPServer):
        self.server = server

    def request(self, req: dict) -> dict:
        return self.server.handle(req)


class MCPClient:
    def __init__(self, transport):
        self.transport = transport
        self._id = 0
        self.tools = []

    def _rpc(self, method, params=None):
        self._id += 1
        req = {"jsonrpc": "2.0", "id": self._id, "method": method}
        if params is not None:
            req["params"] = params
        resp = self.transport.request(req)
        if "error" in resp:
            raise MCPError(resp["error"]["message"])
        return resp["result"]

    def initialize(self):
        return self._rpc("initialize", {"clientInfo": {"name": "veriagent", "version": "0.1"}})

    def list_tools(self):
        self.tools = self._rpc("tools/list").get("tools", [])
        return self.tools

    def call_tool(self, name, args):
        return self._rpc("tools/call", {"name": name, "arguments": args})

    def tool_names(self):
        return [t["name"] for t in self.tools]
